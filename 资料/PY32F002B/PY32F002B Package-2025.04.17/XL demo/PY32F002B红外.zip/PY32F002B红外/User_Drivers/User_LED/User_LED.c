#include "User_LED.h"

void User_LED_Init(void)
{
  GPIO_InitTypeDef  GPIO_InitStruct;

  __HAL_RCC_GPIOA_CLK_ENABLE();                          /* Enable GPIOA clock */

  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;            /* Push-pull output */
  GPIO_InitStruct.Pull = GPIO_PULLUP;                    /* Enable pull-up */
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;          /* GPIO speed */  
  /* GPIO initialization */
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct); 

//  	GPIO_InitStruct.Pin = GPIO_PIN_2;
//	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct); 

//  	GPIO_InitStruct.Pin = GPIO_PIN_3;
//	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct); 
	
	
}

